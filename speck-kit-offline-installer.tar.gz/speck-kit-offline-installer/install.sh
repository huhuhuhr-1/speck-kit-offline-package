#!/bin/bash
set -e

echo "[INFO] 安装 Spe Kit..."

# 检查 Python
if ! command -v python3 >/dev/null 2>&1; then
    echo "[ERROR] 需要 Python 3.11+"
    exit 1
fi

# 安装 Spec Kit
echo "[INFO] 安装 Spec Kit..."
if [ -d "packages" ] && [ -n "$(ls packages/*.whl 2>/dev/null)" ]; then
    echo "[INFO] 使用本地依赖包"
    python3 -m pip install --user --find-links packages --no-index speck-cli typer click rich 2>/dev/null || true
else
    echo "[INFO] 从网络安装"
    python3 -m pip install --user speck-cli
fi

# 设置环境变量
echo "[INFO] 配置环境变量..."
SHELL_CONFIG="$HOME/.bashrc"
if [ -n "$ZSH_VERSION" ]; then
    SHELL_CONFIG="$HOME/.zshrc"
fi

echo "export SPECIFY_TEMPLATE_DIR=\$(pwd)/templates" >> "$SHELL_CONFIG"
echo "export PATH=\$HOME/.local/bin:\$PATH" >> "$SHELL_CONFIG"

echo "[INFO] 安装完成！"
echo "[INFO] 请运行: source $SHELL_CONFIG"
echo "[INFO] 然后使用: specify init my-project --ai claude"
